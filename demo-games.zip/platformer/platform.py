#Copyright 2013 Wong Cho Ching <https://sadale.net>
#
#Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following #conditions are met:
#
#1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
#
#2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
#
#THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE #OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import pygame, sys, math
from pygame.locals import *

fastMovement, movement, jump, bump, gravity = 8, 5, 25, 10, 2

class Object(object):
	def __init__(self, x, y, spritePath):
		self.sprite = pygame.image.load(spritePath)
		self.w, self.h = self.sprite.get_width(), self.sprite.get_height()
		self.x, self.y = x, y
		self.landed = False
		self.type = -1
		self.active = False

		if type(self) == Player:
			self.team = 0
		else:
			self.team = 1
		self.velX, self.velY = 0, 0
	def update(self):
		self.x += self.velX
		self.y += self.velY
	def blit(self):
		windowSurfaceObject.blit(self.sprite,  (self.x-scrollX,  self.y-scrollY))
	def collision(self, obj, case): #dummy function
		pass
	def fallOut(self):
		global dynamicObject
		dynamicObject.remove(self)

class Player(Object):
	w, h = 32, 22
	def __init__(self, x, y):
		super(Player, self).__init__(x, y, "playerRect.png")
		self.code = 'P'
		global screenWidth, screenHeight
		self.faceRight = True
		self.landed = True
		self.active = True
		self.type = "dynamicEntity"
	def update(self):
		super(Player, self).update()
		global screenWidth, scrollX
		if self.x-scrollX < screenWidth/4 and self.velX < 0:
			scrollX += self.velX
		elif self.x-scrollX > screenWidth/2 and self.velX > 0:
			scrollX += self.velX
		if scrollX < 0:
			scrollX = 0
	def collision(self, obj, case):
		global gameOver
		if obj == "bound":
			return
		if obj.type == "dynamicEntity":
			if obj.team != self.team:
				if case == "floor":
					self.y = obj.y-self.h
					self.velY = -bump
				else:
					gameOver = True
		elif type(obj) == Goal:
			global win
			win = True
	def fallOut(self):
		global gameOver
		gameOver = True

class Block(Object):
	w, h = 32, 32
	def __init__(self, x, y):
		super(Block, self).__init__(x, y, "block.png")
		self.code = 'B'

class Goal(Object):
	w, h = 32, 32
	def __init__(self, x, y):
		super(Goal, self).__init__(x, y, "player.png")
		self.code = 'G'
		self.active = True

class Enemy(Object):
	w, h = 32, 32
	def __init__(self, x, y):
		super(Enemy, self).__init__(x, y, "enemy.png")
		self.code = 'E'
		self.velX = -2
		self.type = "dynamicEntity"
	def collision(self, obj, case):
		#if obj.type == "dynamicEntity":
		#	if obj.team == self.team and ( case == "side" or case == "enemy" ):
		#		self.velX = -self.velX
		if case == "side":
			self.velX = -self.velX
		if type(obj) == Player and case == "top":
			global dynamicObject
			dynamicObject.remove(self)
	def update(self):
		if not self.active and scrollX+screenWidth >= self.x:
			self.active = True
		if self.active:
			super(Enemy, self).update()

def blitText(text, x, y, color=pygame.Color(0,  0,  0)):
	global windowSurfaceObject
	message = fontObject.render(text, False, color)
	messageRect = message.get_rect()
	messageRect.topleft = (x, y)
	windowSurfaceObject.blit(message, messageRect)

def buildFloor():
	global floorBuilt, block
	if scrollX+screenWidth >= floorBuilt:
		for i in range(floorBuilt, floorBuilt+screenWidth, Block.w):
			for j in range(screenHeight-Block.h*2, screenHeight, Block.h):
				block.append(Block(i, j))
		floorBuilt += screenWidth

def checkCollision():
	global dynamicObject, gameOver, edit
	player.landed = False
	toCheckTop = []
	for d in dynamicObject:
		for	b in block:
			if not edit or type(d) == Player:
				if d.x+d.w > b.x and d.x < b.x+b.w and d.y < b.y+b.h and d.y+d.h > b.y:
					if (d.y+d.h)-d.velY == b.y or ( (d.y+d.h)-d.velY < b.y and (d.x+d.w)-d.velX > b.x and d.x-d.velX < b.x+b.w ): #push back to the top
						toCheckTop.append([d,b]) # do side collision first, check for top collision finally to fix wall climb bug.
					elif (d.x+d.w)-d.velX <= b.x: #push back to the left
						d.x = b.x-d.w
						d.collision(b, "side")
					elif d.x-d.velX >= b.x+b.w: #push back to the right
						d.x = b.x+b.w
						d.collision(b, "side")
					elif d.y-d.velY >= b.y+b.h: #push back to the down
						d.velY = 0
						d.y = b.y+b.h
						d.collision(b, "top")

	for t in toCheckTop:
		d, b= t[0], t[1]
		if d.x+d.w > b.x and d.x < b.x+b.w and d.y < b.y+b.h and d.y+d.h > b.y:
			if (d.y+d.h)-d.velY == b.y or ( (d.y+d.h)-d.velY < b.y and (d.x+d.w)-d.velX > b.x and d.x-d.velX < b.x+b.w ): #push back to the top
				d.landed = True
				d.velY = 0
				d.y = b.y-d.h
				d.collision(b, "floor")

	if not edit:
		dCount = 0
		for d in dynamicObject[:]:
			for e in dynamicObject[dCount+1:]:
				if d.active and e.active:
					if d.x+d.w > e.x and d.x < e.x+e.w and d.y < e.y+e.h and d.y+d.h > e.y:
						if (d.y+d.h)-d.velY == e.y-e.velY or ( (d.y+d.h)-d.velY < e.y-e.velY and (d.x+d.w)-d.velX > e.x-e.velX and d.x-d.velX < e.x+e.w-e.velX ):
							d.collision(e, "floor")
							e.collision(d, "top")
						elif (d.x+d.w)-d.velX <= e.x-e.velX or d.x-d.velX >= e.x+e.w-e.velX:
							d.collision(e, "side")
							e.collision(d, "side")
						else:
							d.collision(e, "top")
							e.collision(d, "floor")
			dCount += 1

	for d in dynamicObject[:]:
		if d.y > screenHeight:
			d.fallOut()
		elif d.x < 0:
			d.x = 0
			d.collision("bound", "side")

def erase(x, y):
	global dynamicObject, block
	for d in dynamicObject:
		if x >= d.x and x < d.x+d.w and y > d.y and y <= d.y+d.h and d != player:
			dynamicObject.remove(d)
			return
	for b in block:
		if x >= b.x and x < b.x+b.w and y > b.y and y <= b.y+b.h:
			block.remove(b)
			return

def saveMap():
	mapData = [[ "_" for j in range(int(floorBuilt/Block.w)) ] for i in range(int(screenHeight/Block.h))]
	for b in block:
		mapData[int(b.y/Block.h)][int(b.x/Block.w)] = b.code
	for d in dynamicObject:
		mapData[int(d.y/Block.h)][int(d.x/Block.w)] = d.code

	f = open('map', 'w+')
	f.write(str(floorBuilt)+"\n")
	f.write(str(scrollX)+"\n")
	f.write(str(scrollY)+"\n")
	for i in xrange(int(floorBuilt/screenWidth)): #column blocks
		f.write("["+str(i)+"]\n")
		f.write("\t"+"\t".join( [ chr(n+ord('a')) for n in range(0, int(screenWidth/Block.w)) ] )+"\n")
		for j in xrange(int(screenHeight/Block.h)): #rows
			f.write(str(j)+"\t"+"\t".join(mapData[j][i*int(screenWidth/Block.w):(i+1)*int(screenWidth/Block.w)])+"\n")
		f.write("\n")
	f.close()

def removeComments(x):
	return not ( ( x >= '0' and x <= '9' ) or x == '\t' or x == '\n' )


def loadMap():
	try:
		global floorBuilt, dynamicObject, block, player
		f = open('map', 'r')
		floorBuilt = int(f.readline())
		scrollX = int(f.readline())
		scrollY = int(f.readline())
		mapData = [[ "_" for j in range(int(floorBuilt/Block.w)) ] for i in range(int(screenHeight/Block.h))]
		for i in xrange(int(floorBuilt/screenWidth)): #column blocks
			f.readline() #get rid of column block id
			f.readline() #get rid of column name
			for j in xrange(int(screenHeight/Block.h)): #rows
				dummy = f.readline()
				dummy = filter(removeComments, dummy)
				for k in xrange(int(screenWidth/Block.w)): # column
					x, y = i*screenWidth+k*Block.w, j*Block.h
					if dummy[k] == 'P':
						player.x, player.y = x, y
					elif dummy[k] == 'B':
						block.append(Block(x, y))
					elif dummy[k] == 'G':
						dynamicObject.append(Goal(x, y))
					elif dummy[k] == 'E':
						dynamicObject.append(Enemy(x, y))
			f.readline() #get rid of line feed
	except IOError as e:
		return False
	return True

	

pygame.init()
fpsClock = pygame.time.Clock()
fontObject = pygame.font.SysFont("Arial" ,  15)
soundGameOver = pygame.mixer.Sound("gameover.ogg")
soundWin = pygame.mixer.Sound("win.ogg")
BGM = pygame.mixer.Sound("bgm.ogg")

screenWidth, screenHeight = 640, 480
windowSurfaceObject = pygame.display.set_mode((screenWidth,  screenHeight))
pygame.display.set_caption("Simple Platform Game")

edit = True
while True:
	leftHold, rightHold, shiftHold = False, False, False
	gameOver = False
	win = False
	scrollX, scrollY = 0, 0
	for event in pygame.event.get(): # get rid of all events
		pass
	dynamicObject = []
	block = []
	floorBuilt = 0
	player = Player(0, screenHeight-Player.h-Block.h*3)
	if not loadMap():
		buildFloor()
	dynamicObject.append(player)
	showHelp = False

	while ( not gameOver and not win ) or edit:
		prevTick = pygame.time.get_ticks()
		windowSurfaceObject.fill(pygame.Color(255,  255,  255))
		for event in pygame.event.get():
			if event.type == QUIT:
				pygame.quit()
				sys.exit()
			elif event.type == KEYDOWN:
				if( event.key == K_LEFT or event.key == K_a ) and player.velX > -movement:
					if player.faceRight:
						player.sprite = pygame.transform.flip(player.sprite, True, False)
						player.faceRight = False
					leftHold = True
				elif ( event.key == K_RIGHT or event.key == K_d ) and player.velX < movement:
					if player.faceRight == False:
						player.sprite = pygame.transform.flip(player.sprite, True, False)
						player.faceRight = True
					rightHold = True
				elif ( event.key == K_UP or event.key == K_w ) and player.landed:
					player.velY -= jump
				elif event.key == K_LSHIFT:
					shiftHold = True
				elif event.key == K_RETURN:
					edit = not edit
					if not edit:
						BGM.play(-1)
					else:
						BGM.stop()
					gameOver = False
				elif event.key == K_r and edit:
					scrollX, scrollY = 0, 0
					player.x, player.y = 0, screenHeight-Player.h-Block.h*3
				elif event.key == K_F5 and edit:
					saveMap()
				elif event.key == K_F1 and edit:
					showHelp = not showHelp
				elif event.key == K_PERIOD and edit:
					scrollX += screenWidth/2
				elif event.key == K_COMMA and edit:
					scrollX -= screenWidth/2
					if scrollX < 0:
						scrollX = 0
			elif event.type == KEYUP:
				if event.key == K_LEFT or event.key == K_a:
					leftHold = False
				elif event.key == K_RIGHT or event.key == K_d:
					rightHold = False
				elif event.key == K_LSHIFT:
					shiftHold = False
			elif event.type == MOUSEBUTTONDOWN and edit:
				if event.button == 1:
					erase(event.pos[0]+scrollX, event.pos[1]+scrollY)
					block.append(Block(int((event.pos[0]+scrollX)/Block.w)*Block.w, int((event.pos[1]+scrollY)/Block.h)*Block.h))
				elif event.button == 3:
					erase(event.pos[0]+scrollX, event.pos[1]+scrollY)
					dynamicObject.append(Enemy(int((event.pos[0]+scrollX)/Enemy.w)*Enemy.w, int((event.pos[1]+scrollY)/Enemy.h)*Enemy.h))
				elif event.button == 2:
					erase(event.pos[0]+scrollX, event.pos[1]+scrollY)
				elif event.button == 4:
					player.x, player.y, player.velX, player.velY = event.pos[0]+scrollX, event.pos[1]+scrollY, 0, 0
				elif event.button == 5:
					erase(event.pos[0]+scrollX, event.pos[1]+scrollY)
					for d in dynamicObject:
						if type(d) == Goal:
							dynamicObject.remove(d)
					dynamicObject.append(Goal(int((event.pos[0]+scrollX)/Goal.w)*Goal.w, int((event.pos[1]+scrollY)/Goal.h)*Goal.h))
		for d in dynamicObject:
			if type(d) == Player or ( d.active and d.type == "dynamicEntity" and not edit):
				d.velY += gravity
				if d.velY > d.h:
					d.velY = d.h

		if shiftHold:
			velocity = fastMovement
		else:
			velocity = movement
		if leftHold and rightHold == False:			
			player.velX = -velocity
		elif rightHold and leftHold == False:
			player.velX = velocity
		else:
			player.velX = 0

		for d in dynamicObject:
			if edit == False or type(d) == Player:
				d.update()
		checkCollision()
		for	b in block:
			b.blit()
		for d in dynamicObject:
			d.blit()

		if edit:
			blitText("Edit mode. <F1>show/dismiss detailed help <F5>save <enter>start game", 10, 10)
			if showHelp:
				blitText("<wasd> or <arrow> to control the character <Shift>to run faster ", 10, 40)
				blitText("<R>reset scrolling <Left click>create block", 10, 70)
				blitText("<Right click>create enemy <MMB>erase", 10, 100)
				blitText("<Scroll up>move player to current mouse position <Scroll down>place goal", 10, 130)
				blitText("<,>scroll left <.>scroll", 10, 160)


		buildFloor()

		pygame.display.update()
		fpsClock.tick(30)
	BGM.stop()
	if win:
		channel = soundWin.play()
	else:
		channel = soundGameOver.play()
	while  channel.get_busy() == True:
		for event in pygame.event.get():
			if event.type == QUIT:
				pygame.quit()
				sys.exit()
	BGM.play(-1)
