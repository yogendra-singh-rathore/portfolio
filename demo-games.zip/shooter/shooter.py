#Copyright 2013 Wong Cho Ching <https://sadale.net>
#
#Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following #conditions are met:
#
#1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
#
#2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
#
#THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE #OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import pygame, sys
from pygame.locals import *
import random
import math

bulletR, playerR, enemyR = 4, 16, 16
controlVel = 5;

class PlayerObject:
	def __init__(self):
		self.sprite = pygame.image.load("player.png")
		self.x,  self.y, self.velX, self.velY = 0, 0, 0, 0
	def update(self):
		self.x += self.velX
		self.y += self.velY

		global screenWidth, screenHeight
		if self.x < 0:
			self.x = 0
		elif self.x > screenWidth-playerR*2:
			self.x = screenWidth-playerR*2
		if self.y < 0:
			self.y = 0
		elif self.y > screenHeight-playerR*2:
			self.y = screenHeight-playerR*2
		windowSurfaceObject.blit(self.sprite,  (self.x,  self.y))

class EnemyObject:
	def __init__(self):
		self.sprite = pygame.image.load("enemy.png")
		global player, screenWidth, screenHeight
		self.x,  self.y, self.velX, self.velY = random.randrange(0,screenWidth-enemyR*2),  random.randrange(0,screenHeight-enemyR*2), 0, 0
		tries = 0
		while tries < 100 and math.hypot(player.x-self.x, player.y-self.y) < playerR+enemyR+20:
			self.x,  self.y = random.randrange(0,screenWidth-enemyR),  random.randrange(0,screenHeight-enemyR)
			tries += 1

	def update(self):
		self.x += self.velX
		self.y += self.velY
		global bullet, kills
		if 98-kills < 75:
			safe = 75
		else:
			safe = 98-kills

		if random.randrange(0,100) > safe:
			x, y = random.randrange(-10,10), random.randrange(-10,10)
			bullet.append(BulletObject("enemy", self.x+enemyR-bulletR, self.y+enemyR-bulletR, random.randrange(-10,10), random.randrange(-10,10)))
		windowSurfaceObject.blit(self.sprite,  (self.x,  self.y))

class BulletObject:
	def __init__(self, owner, x, y, velX, velY):
		self.sprite = pygame.image.load("projectile.png")
		self.owner, self.x, self.y, self.velX, self.velY = owner, x, y, velX, velY
		if math.fabs(self.velX) < 1 and math.fabs(self.velY) < 1:
			self.velX, self.velY = 1, 1
	def update(self):
		global screenWidth, screenHeight, bullet
		self.x += self.velX
		self.y += self.velY
		windowSurfaceObject.blit(self.sprite,  (self.x,  self.y))

pygame.init()
fpsClock = pygame.time.Clock()
screenWidth, screenHeight = 640, 480
windowSurfaceObject = pygame.display.set_mode((screenWidth,  screenHeight))
pygame.display.set_caption("Genetic Game")

soundGameOver = pygame.mixer.Sound("gameover.ogg")
soundShoot = pygame.mixer.Sound("shoot.ogg")

def checkCollision():
	global enemy, bullet, player, enermyBullet, gameOver, kills
	for e in enemy:
		if math.hypot(player.x-e.x, player.y-e.y) < playerR+enemyR:
			gameOver = True

	for b in bullet:
		if b.owner == "enemy" and math.hypot(player.x-b.x+playerR-bulletR, player.y-b.y+playerR-bulletR) < playerR+bulletR:
			gameOver = True
			break

	for e in enemy:
		for b in bullet:
			if b.owner == "player" and math.hypot(e.x-b.x+enemyR-bulletR, e.y-b.y+enemyR-bulletR) < enemyR+bulletR:
				enemy.remove(e)
				bullet.remove(b)
				kills += 1
				break


	for b in bullet:
		if b.x-bulletR < 0 or b.x > screenWidth or b.y < 0 or b.y > screenHeight:
			bullet.remove(b)

fontObject = pygame.font.SysFont("Arial" ,  24)
def blitText(text, x, y, color=pygame.Color(0,  0,  0)):
	global windowSurfaceObject
	message = fontObject.render(text, False, color)
	messageRect = message.get_rect()
	messageRect.topleft = (x, y)
	windowSurfaceObject.blit(message, messageRect)

while True:
	for event in pygame.event.get():
		pass
	player = PlayerObject()
	enemy = []
	bullet = []
	previousAddEnermyTick = pygame.time.get_ticks();
	kills = 0;
	gameOver = False
	while True:
		windowSurfaceObject.fill(pygame.Color(255,  255,  255))
		for event in pygame.event.get():
			if event.type == QUIT:
				pygame.quit()
				sys.exit()
			elif event.type == KEYDOWN:
				if event.key == K_LEFT:
					player.velX -= controlVel
				elif event.key == K_RIGHT:
					player.velX += controlVel
				elif event.key == K_UP:
					player.velY -= controlVel
				elif event.key == K_DOWN:
					player.velY += controlVel
			elif event.type == KEYUP:
				if event.key == K_LEFT:
					player.velX += controlVel
				elif event.key == K_RIGHT:
					player.velX -= controlVel
				elif event.key == K_UP:
					player.velY += controlVel
				elif event.key == K_DOWN:
					player.velY -= controlVel
				elif event.key == K_SPACE:
					count = 0
					for b in bullet:
						if b.owner == "player":
							count += 1
					if count < 5:
						soundShoot.play()
						if player.velX == 0 and player.velY == 0:
							bullet.append(BulletObject("player", math.fabs(player.x)+(playerR-bulletR), math.fabs(player.y)+(playerR-bulletR),random.randrange(-10,10), random.randrange(-10,10)))
						else:
							bullet.append(BulletObject("player", math.fabs(player.x)+(playerR-bulletR), math.fabs(player.y)+(playerR-bulletR), player.velX*2, player.velY*2))

		checkCollision()
		if gameOver==True:
			break;

		player.update()
		for e in enemy:
			e.update()
		for b in bullet:
			b.update()

		if pygame.time.get_ticks()-previousAddEnermyTick > 3000/math.log(kills+5,5):
			enemy.append(EnemyObject())
			previousAddEnermyTick = pygame.time.get_ticks()
		blitText("score:"+str(kills), 10, 10)
		blitText("spawn: "+str(pygame.time.get_ticks()-previousAddEnermyTick)+"/"+str(3000/math.log(kills+5,5)), 10, screenHeight-30)

		pygame.display.update()
		fpsClock.tick(30)

	channel = soundGameOver.play()
	while channel.get_busy() == True:
		pass

